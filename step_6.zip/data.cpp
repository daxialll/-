#include<iostream>
#include"date.h"
using namespace std;
namespace
{	
	const int DAYS_BEFORE_MONTH[] = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };
}//ĳ��1�յ�1��1�ն�����

Date::Date(int year, int month, int day)
{
	this->year = year;
	this->month=month;
	this->day=day;
	int years = year - 1;
	totalDays = years * 365 + years / 4 - years / 100 + years / 400+ DAYS_BEFORE_MONTH[month - 1] + day;
	if (isLeapYear() && month > 2) totalDays++;
}
void Date::show()const
{
	cout << getYear() <<"-" << getMonth() <<"-" << getDay();
}
int Date::getYear()const
{
	return year;
}
int Date::getMonth()const
{
	return month;
}
int Date::getDay()const
{
	return day;
}
bool Date::isLeapYear()const
{
	return year % 4==0 && year % 100 != 0 || year % 400 == 0;
}
int Date::getMaxDay()const
{
		if (isLeapYear() && month == 2)
			return 29;
		else
			return DAYS_BEFORE_MONTH[month] - DAYS_BEFORE_MONTH[month - 1];
}
Date Date::read()
{
	int year, month, day;
	cin >> year >> month >> day;
	return Date(year, month, day);
}