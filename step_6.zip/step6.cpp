//step5.cpp

#include "account.h"

#include <iostream>

#include <vector>

#include <algorithm>

#include<fstream>

using namespace std;



struct deleter {

	template <class T> void operator () (T* p) { delete p; }

};



int main() {
	ofstream ofs;
	ofs.open("commands", ios::app);

	Date date(2008, 11, 1);//��ʼ����

	vector<Account*> accounts;//�����˻����飬Ԫ�ظ���Ϊ0
	
				
				// �ָ�����
				ifstream ifs("commands");
				if (ifs) {
					char rcmd;
					while (ifs >> rcmd) {
						char type;
						int index, day;
						double amount, credit, rate, fee;
						string id, desc;
						Account* account;

						switch (rcmd) {
						case 'a':
							ifs >> type >> id;
							if (type == 's') {
								ifs >> rate;
								account = new SavingsAccount(date, id, rate);
							}
							else {
								ifs >> credit >> rate >> fee;
								account = new CreditAccount(date, id, credit, rate, fee);
							}
							accounts.push_back(account);
							break;
						case 'd':
							ifs >> index >> amount;
							getline(ifs, desc);  // ��ȡ������������ǰ���ո�
							accounts[index]->deposit(date, amount, desc);
							break;
						case 'w':
							ifs >> index >> amount;
							getline(ifs, desc);
							accounts[index]->withdraw(date, amount, desc);
							break;
						case 'c':
							ifs >> day;
							if (day >= date.getDay() && day <= date.getMaxDay()) {
								date = Date(date.getYear(), date.getMonth(), day);
							}
							break;
						case 'n':
							if (date.getMonth() == 12)
								date = Date(date.getYear() + 1, 1, 1);
							else
								date = Date(date.getYear(), date.getMonth() + 1, 1);
							for (auto a : accounts) a->settle(date);
							break;
						case 'q':
							int y1, m1, d1, y2, m2, d2;
							ifs >> y1 >> m1 >> d1 >> y2 >> m2 >> d2;
							Account::query(Date(y1, m1, d1), Date(y2, m2, d2));
							break;
						}
					}
				}
				ifs.close();
				cout << "(a)add account (d)deposit (w)withdraw (s)show (c)change day (n)next month (q)query (e)exit" << endl;
				char cmd;
				do {

					//��ʾ���ں��ܽ��

					date.show();

					cout << "\tTotal: " << Account::getTotal() << "\tcommand> ";



					char type;

					int index, day;

					double amount, credit, rate, fee;

					string id, desc;

					Account* account;

					Date date1, date2;



					cin >> cmd;

					if (cmd != 'e')ofs << cmd << " ";
					switch (cmd) {

					case 'a'://�����˻�

						cin >> type >> id;
						ofs << type << " " << id;
						if (type == 's') {

							cin >> rate;
							ofs << " " << rate << endl;
							account = new SavingsAccount(date, id, rate);

						}

						else {

							cin >> credit >> rate >> fee;
							ofs << credit << " " << rate << " " << fee << endl;
							account = new CreditAccount(date, id, credit, rate, fee);

						}

						accounts.push_back(account);

						break;

					case 'd'://�����ֽ�

						cin >> index >> amount;
						ofs << index << " " << amount;
						getline(cin, desc);
						ofs << " " << desc << " " << endl;
						accounts[index]->deposit(date, amount, desc);

						break;

					case 'w'://ȡ���ֽ�

						cin >> index >> amount;
						ofs << index << " " << amount;
						getline(cin, desc);
						ofs << " " << desc << endl;
						accounts[index]->withdraw(date, amount, desc);

						break;

					case 's'://��ѯ���˻���Ϣ

						for (size_t i = 0; i < accounts.size(); i++) {

							cout << "[" << i << "] ";

							accounts[i]->show();

							cout << endl;

						}

						break;

					case 'c'://�ı�����

						cin >> day;
						ofs << day << endl;
						if (day < date.getDay())

							cout << "You cannot specify a previous day";

						else if (day > date.getMaxDay())

							cout << "Invalid day";

						else

							date = Date(date.getYear(), date.getMonth(), day);

						break;

					case 'n'://�����¸���

						if (date.getMonth() == 12)

							date = Date(date.getYear() + 1, 1, 1);

						else

							date = Date(date.getYear(), date.getMonth() + 1, 1);

						for (vector<Account*>::iterator iter = accounts.begin(); iter != accounts.end(); ++iter)

							(*iter)->settle(date);

						break;

					case 'q'://��ѯһ��ʱ���ڵ���Ŀ

						date1 = Date::read();

						date2 = Date::read();

						Account::query(date1, date2);

						break;

					}

				} while (cmd != 'e');





				for_each(accounts.begin(), accounts.end(), deleter());
				ofs.close();
				return 0;

			}
		