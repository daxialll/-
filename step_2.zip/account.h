#pragma once
#include"date.h"
#include<string>
class SavingsAccount
{
private:
	std::string id;
	double balance;
	double rate;
	Date lastDate;
	double accumulation;
	static double total;
public:
	SavingsAccount(const Date &, const std::string&, double);
	void record(const Date&, double,const std::string&);
	double accumulate(const Date&);
	std::string getId()const;
	double getBalance()const;
	double getRate()const;
	void show()const;
	void deposit(const Date&, double,const std::string &);
	void withdraw(const Date&, double,const std::string&);
	void settle(const Date&);
	static double getTotal();
};