#pragma once
class Date
{
private:
	int year;
	int month;
	int day;
	int allDay;
public:
	Date(int, int, int);
	void show()const;
	int getYear()const;
	int getMonth()const;
	int getDay()const;
	bool leapyear()const;
	int gap(const Date&)const;
};