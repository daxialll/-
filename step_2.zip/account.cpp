#include"account.h"
#include<iostream>
#include<cmath>
using namespace std;
double SavingsAccount::total = 0;
void SavingsAccount::record(const Date& date, double amount,const string&reason)
{
	accumulation = accumulate(date);
	lastDate = date;
	amount = floor(amount * 100 + 0.5) / 100;
	balance += amount;
	total += amount;
	lastDate.show();
	cout<< "\t#" << id << "\t" << amount << " " << balance <<"\t" << reason << endl;
}
SavingsAccount::SavingsAccount(const Date &date, const string &id, double rate):lastDate(date)
{
	this->id = id;
	this->rate = rate;
	balance = 0;
	accumulation = 0;
	lastDate.show();
	cout<< "\t" << "#" << id << " " << "created" << endl;
}
string SavingsAccount::getId()const
{
	return id;
}
double SavingsAccount::getBalance()const
{
	return balance;
}
double SavingsAccount::getRate()const
{
	return rate;
}
void SavingsAccount::show()const
{
	cout << id << "\t" << "Balance: " << balance ;
}
void SavingsAccount::deposit(const Date&date, double amount,const string&reason)
{
	record(date, amount,reason);
}
void SavingsAccount::withdraw(const Date&date, double amount,const string&reason)
{
	if (amount > balance)
	{
		cout << "����" << endl;
	}
	else
		record(date, -amount,reason);
}
void SavingsAccount::settle(const Date& date)
{
	double profit;
	profit = accumulate(date) * rate / 366;
	record(date, profit,"interest");
}
 double SavingsAccount:: getTotal()
{
	return total;
}
 double SavingsAccount::accumulate(const Date& date)
 {
	 return accumulation + balance * date.gap(lastDate);
 }