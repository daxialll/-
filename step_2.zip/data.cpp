#include<iostream>
#include"date.h"
#include<cstdlib>
using namespace std;
namespace
{	
	const int DAYS_BEFORE_MONTH[] = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };
}//ĳ��1�յ�1��1�ն�����

Date::Date(int year, int month, int day)
{
	this->year = year;
	this->month=month;
	this->day=day;
	int years = year - 1;
	allDay = years * 365 + years / 4 - years / 100 + years / 400+ DAYS_BEFORE_MONTH[month - 1] + day;
	if (leapyear() && month > 2) allDay++;
}
void Date::show()const
{
	cout << getYear() <<"-" << getMonth() <<"-" << getDay();
}
int Date::getYear()const
{
	return year;
}
int Date::getMonth()const
{
	return month;
}
int Date::getDay()const
{
	return day;
}
bool Date::leapyear()const
{
	return year % 4==0 && year % 100 != 0 || year % 400 == 0;
}
int Date::gap(const Date&date)const
{
	return allDay - date.allDay;
}