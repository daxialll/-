#pragma once
class Date
{
private:
	int year;
	int month;
	int day;
	int totaldays;
public:
	Date(int, int, int);
	int getYear()const;
	int getMonth()const;
	int getDay()const;
	int getMaxday()const;
	bool isLeapYear()const;
	void show()const;
	int distance(const Date&date)const;
};