#pragma once
#include"date.h"
#include"Accumulator.h"
#include<string>
//Account
class Account
{private:
	std::string id;
	double balance;
	static double total;
public:
	Account(const Date&date, const std::string&id);
	void record(const Date&date, double amount,  const std::string&desc);
	void error(const std::string&msg)const;
	std::string getId()const;
	double getBalance()const;
	void show()const;
	static double getTotal();
};
//SavingsAccount
class SavingsAccount: public Account
{
private:
	Accumulator acc;
	double rate;
public:
	SavingsAccount(const Date& date, const std::string& id, double rate);
	double getRate()const;
	void deposit(const Date& date, double amount, const std::string& desc);
	void withdraw(const Date& date, double amount, const std::string& desc);
	void settle(const Date& date);
};
//CreditAccount
class CreditAccount:public Account
{
private:
	Accumulator acc;
	double credit;
	double rate;
	double fee;
public:
	double getDebt()const;
	CreditAccount(const Date& date, const std::string& id, double credit, double rate, double fee);
	double getCredit()const;
	double getRate()const;
	double getFee()const;
	double getAvailableCredit()const;
	void deposit(const Date& date, double amount, const std::string& desc);
	void withdraw(const Date& date, double amount, const std::string& desc);
	void settle(const Date& date);
	void show()const;
};