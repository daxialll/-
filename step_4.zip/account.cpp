#include"account.h"
#include<iostream>
#include<cmath>
using namespace std;
double Account::total = 0;
//SavingsAccount
SavingsAccount::SavingsAccount(const Date &date, const string &id, double rate):Account(date,id),acc(date,0)
{
	this->rate = rate;
}
double SavingsAccount::getRate()const
{
	return rate;
}
void SavingsAccount::deposit(const Date&date, double amount,const string&desc)
{
	record(date, amount,desc);
	acc.change(date, getBalance());
}
void SavingsAccount::withdraw(const Date& date, double amount, const string& desc)
{
	if (amount > getBalance())
	{
		cout << "����" << endl;
	}
	else
	{
		record(date, -amount, desc);
		acc.change(date,getBalance());
	}
}
void SavingsAccount::settle(const Date& date)
{
	if (date.getMonth() == 1)
	{
		double profit;
		profit = acc.getSum(date) * rate / (date.distance(Date(date.getYear() - 1, 1, 1)));
		if(profit!=0)
			record(date, profit, "interest");
		acc.reset(date, getBalance());
	}
}
 //Account
void Account::error(const string& msg) const
{
	cout << "Error(#" << id << "): " << msg << endl;
}
Account::Account(const Date& date, const string& id)
{
	balance = 0;
	this->id = id;
	date.show();
	cout << "\t#" << id<< " created"<<endl;
}
string Account::getId()const
 {
	return id;  
 }
double Account::getBalance()const
{
	return balance;
}
void Account::show()const
{
	cout << id << "\t" << "Balance: " << balance;
}
void Account::record(const Date& date, double amount, const string& reason)
{
	amount = floor(amount * 100 + 0.5) / 100;
	balance += amount;
	total += amount;
	date.show();
	cout << "\t#" << id << "\t" << amount << " " << balance << "\t" << reason << endl;
}
double Account::getTotal()
{
	return total;
}
//CreditAccount
double CreditAccount::getDebt()const
{
	if(getBalance()<0)
	return getBalance();
	return 0;
}
CreditAccount::CreditAccount(const Date& date, const string& id, double credit, double rate, double fee)
	:Account(date,id),credit(credit),rate(rate),fee(fee),acc(date,0)
{
	
	}

double CreditAccount::getCredit()const
{
	return credit;
	}
double CreditAccount::getRate()const
{
	return rate;
	}
double CreditAccount::getFee()const
{
	return fee;
}
double CreditAccount::getAvailableCredit()const
{
	if (getBalance() < 0)return credit + getDebt();
	else return credit;
}
void CreditAccount::deposit(const Date& date, double amount, const string& desc)
{
	record(date, amount, desc);
	acc.change(date, getDebt());
}
void CreditAccount::withdraw(const Date& date, double amount, const string& desc)
{
	record(date, -amount, desc);
	acc.change(date, getDebt());
}
void CreditAccount::settle(const Date& date)
{
	double interest = acc.getSum(date) * rate;
    if(interest!=0)
	record(date, interest, "interest");
	if (date.getMonth() == 1)
	{
		record(date, -fee, "annual fee");
	}
	acc.reset(date, getBalance());
}
void CreditAccount::show()const
{
	Account::show();
	cout << "\t" << "Available credit:" << getAvailableCredit();
}