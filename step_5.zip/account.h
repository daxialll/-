#pragma once
#include"date.h"
#include"Accumulator.h"
#include<string>
#include<map>
//AccountRecord
class Account;
class AccountRecord
{
private:
	Date date;
	const Account *account;
	double amount;
	double balance;
	std::string desc;
public:
	void show()const
	{
		std::cout << amount << balance << desc;
	}
	const Date& getDate()const { return date; }
	const Account* getAccount()const { return account; }
	double getAmount()const { return amount; }
	double getBalance()const { return balance; }
	std::string getDesc() { return desc; }
	AccountRecord(const Date& date,const Account* account, double amount, double balance, std::string desc)
		:date(date),account(account),amount(amount),balance(balance),desc(desc)
	{ }
};
//Account
class Account
{
private:
	std::string id;
	double balance;
	static double total;
	static std::multimap<Date, AccountRecord> recordMap;
public:
	Account(const Date& date, const std::string& id);
	void record(const Date& date, double amount, const std::string& desc);
	void error(const std::string& msg)const;
	std::string getId()const;
	double getBalance()const;
	virtual void deposit(const Date& date, double amount, const std::string& desc) = 0;
	virtual void withdraw(const Date& date, double amount, const std::string& desc) = 0;
	virtual void settle(const Date& date) = 0;
	virtual	void show()const;
	static double getTotal();
	static void query(const Date& date1, const Date& date2);
};
//SavingsAccount
class SavingsAccount: public Account
{
private:
	Accumulator acc;
	double rate;
public:
	SavingsAccount(const Date& date, const std::string& id, double rate);
	double getRate()const;
	virtual void deposit(const Date& date, double amount, const std::string& desc);
	virtual void withdraw(const Date& date, double amount, const std::string& desc);
	virtual void settle(const Date& date);
};
//CreditAccount
class CreditAccount:public Account
{
private:
	Accumulator acc;
	double credit;
	double rate;
	double fee;
public:
	double getDebt()const;
	CreditAccount(const Date& date, const std::string& id, double credit, double rate, double fee);
	double getCredit()const;
	double getRate()const;
	double getFee()const;
	double getAvailableCredit()const;
	void deposit(const Date& date, double amount, const std::string& desc);
	virtual void withdraw(const Date& date, double amount, const std::string& desc);
	virtual void settle(const Date& date);
	virtual void show()const;
};