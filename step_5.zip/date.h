#pragma once
#include<iostream>
class Date
{
private:
	int year;
	int month;
	int day;
	int totalDays;
public:
	Date(int=1, int=1, int=1);
	int getYear()const;
	int getMonth()const;
	int getDay()const;
	int getMaxDay()const;
	bool isLeapYear()const;
	void show()const;
	static Date read();
	int operator -(const Date& date)const
	{
		return totalDays - date.totalDays;
	}
	bool operator < (const Date& date)const
	{
		if (year != date.year)return year < date.year;
		if (month != date.month)return month < date.month;
		return day < date.day;
	}
};