#pragma once
class SavingsAccount
{
private:
	int id;
	double balance;
	double rate;
	int lastDate;
	double accumulation;
public:
	SavingsAccount(int, int, double);
	void record(int, double);
	double accumulate(int);
	int getId()const;
	double getBalance()const;
	double getRate()const;
	void show();
	void deposit(int, double);
	void withdraw(int, double);
	void settle(int);
};