#include"account.h"
#include<iostream>
#include<cmath>
using namespace std;
void SavingsAccount::record(int date, double amount)
{
	accumulation = accumulate(date);
	lastDate = date;
	amount = floor(amount * 100 + 0.5) / 100;
	balance += amount;
	cout << lastDate << "\t#" << id << "\t" << amount << " " << balance << endl;
}
SavingsAccount::SavingsAccount(int date, int id, double rate)
{
	this->id = id;
	this->rate = rate;
	lastDate = date;
	balance = 0;
	accumulation = 0;
	cout << date << "\t" << "#" << id << " " << "is created"<<endl;
}
double SavingsAccount::accumulate(int date)
{
	return accumulation + balance * (date - lastDate);
}
int SavingsAccount::getId()const
{
	return id;
}
double SavingsAccount::getBalance()const
{
	return balance;
}
double SavingsAccount::getRate()const
{
	return rate;
}
void SavingsAccount::show()
{
	cout << "#" << id << "\t" << "Balance: " << balance ;
}
void SavingsAccount::deposit(int date, double amount)
{
	record(date, amount);
}
void SavingsAccount::withdraw(int date, double amount)
{
	if (amount > balance)
	{
		cout << "����" << endl;
	}
	else
		record(date, -amount);
}
void SavingsAccount::settle(int date)
{
	double profit;
	profit = accumulate(date) * rate/365;
	record(date, profit);
}